# medicinedb

SQLite medicine database  :pill: :pill: :pill: 

Please note that this database is almost 4 years old and mostly 🇧🇩 Bangladeshi brands related. Although it contains almost all the general medicines information.     

This database is pretty much self-explanatory. Just import **medicine.db** file with any sqlite editor. Here is the table list:

- brand                     
- indication                
- systemic                
- company_name              
- indication_generic_index  
- therapitic              
- generic                   
- pregnancy_category        
- therapitic_generic
